﻿产品名称： Highstock



授权协议：http://highcharts.com.cn/shop/license



版本： 4.2.6



发布时间： 2016-08-08



使用方法：直接打开 index.htm 即可看到我们提供的离线例子清单；所有需要的 js 文件在 /js/ 目录里。



由 Highcharts中文官网发布（http://wwww.hcharts.cn/，http://highcharts.com.cn）
